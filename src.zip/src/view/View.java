package view;

/**
 * @author Alvar Reggio
 * @version 1.0
 */
public class View {
	/**
	 * Gibt Texte in der Console aus.
	 * @param text # Texte, welche ausgegeben werden sollen
	 */
	public void ausgabe(String text) {
		System.out.println(text);
	}
}
